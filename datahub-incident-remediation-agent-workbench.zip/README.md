# DataHub Incident Remediation Agent 🛠️🤖
> **Build with DataHub: The Agent Hackathon** — *Challenge 1: Agents That Do Real Work*  
> Powered by **Google Gemini** (`gemini-2.5-flash` / `gemini-3.6-flash`) & **DataHub Context Platform** (`datahub-agent-context` & DataHub SDKs).

---

## 🌟 Executive Overview

The **DataHub Incident Remediation Agent** is an autonomous DataOps AI agent designed to resolve data quality incidents in modern data stacks before corrupted data impacts executive decision-making.

When a data quality alert or schema anomaly occurs (such as a sudden null value spike or freshness failure), the agent:
1. **Queries DataHub Context Platform** to inspect dataset schemas, column profiles, and test assertion failures.
2. **Traces Upstream Lineage** across pipelines (PostgreSQL → dbt → Snowflake) to pinpoint the exact root-cause source dataset or failing ETL job.
3. **Traces Downstream Lineage** to compute the blast radius and identify affected business intelligence assets (e.g., Tableau Executive Dashboards, Finance reports).
4. **WRITES BACK TO DATAHUB (Mutations Enabled)**: Automatically attaches status tags (e.g., `DATA_QUALITY_ALERT`, `INCIDENT_IN_PROGRESS`), updates dataset ownership, and appends warning notes to entity documentation so data consumers are immediately notified in the DataHub UI.
5. **Generates an Incident Remediation Report**: Produces a structured Markdown root-cause analysis report for data engineering teams.

---

## 📐 Architecture Diagram

```
+-----------------------------------------------------------------------------------+
|                        DataHub Incident Remediation Agent                         |
|                                                                                   |
|   +-----------------------+   DataHub Context    +----------------------------+   |
|   |   Google Gemini LLM   |<====================>|  datahub-agent-context     |   |
|   | (gemini-2.5 / 3.6)    |                      |  (GraphQL & REST Mutator)  |   |
|   +-----------------------+                      +----------------------------+   |
+-----------------------------------------------------------------------------------+
                                         |
                       +-----------------+-----------------+
                       |                                   |
                       v                                   v
         [ 1. Lineage & Metadata Trace ]           [ 2. Mutation Writeback ]
                       |                                   |
    +------------------+-------------------+      +------------+-------------+
    | Upstream: postgres.raw_postgres_orders|      |  Tag: DATA_QUALITY_ALERT |
    | Pipeline: dbt_transformation_hourly  |=====>|  Tag: INCIDENT_IN_PROGRESS |
    | Target: snowflake.fact_daily_orders  |      |  Doc: Incident Note      |
    | Downstream: tableau.executive_dash   |      +--------------------------+
    +--------------------------------------+
```

---

## 🚀 Quickstart Guide for Hackathon Judges

You can run the agent in two modes:
1. **Live Mode**: Connects to a running DataHub instance (via Docker Quickstart).
2. **Simulation Mode**: Dry-run mode that simulates DataHub metadata and lineage without requiring local Docker containers.

---

### Prerequisites

- **Python 3.10+**
- **Google Gemini API Key** (`GOOGLE_API_KEY` or `GEMINI_API_KEY`)
- Optional: **Docker** (if running a live DataHub instance)

---

### Step 1: Clone Repository & Set Up Virtual Environment

```bash
git clone https://github.com/your-username/datahub-incident-remediation-agent.git
cd datahub-incident-remediation-agent

python3 -m venv venv
source venv/bin/activate
```

---

### Step 2: Install Dependencies

```bash
pip install -r requirements.txt
```

---

### Step 3: Configure Environment Variables

Create a `.env` file in the project root:

```env
# Required for Gemini AI Reasoning
GOOGLE_API_KEY="your-google-gemini-api-key"

# Required for Live DataHub Connection (Defaults to http://localhost:8080)
DATAHUB_GMS_URL="http://localhost:8080"
DATAHUB_TOKEN="your-optional-datahub-personal-access-token"

# Model Selection
GEMINI_MODEL="gemini-2.5-flash"
```

---

### Step 4: Run the Agent

#### Option A: Quick Simulation Mode (Instant Test - No Docker Needed) ⚡
To test the agent's reasoning, lineage traversal, and simulated writebacks immediately:

```bash
python agent.py --simulate --task "Investigate null value spike in fact_daily_orders.amount"
```

#### Option B: Live DataHub Instance (Docker Quickstart) 🐳
1. Start local DataHub stack:
   ```bash
   pip install acryl-datahub
   datahub docker quickstart
   ```
2. Ingest sample pipeline metadata or run the agent directly:
   ```bash
   python agent.py --task "Investigate null value spike in fact_daily_orders" --datahub-url "http://localhost:8080"
   ```

---

## 🏷️ How DataHub Mutation Writebacks Work

When `include_mutations=True` is enabled in `DataHubAgentContext`, the agent issues GraphQL mutations to DataHub GMS:

```python
# 1. Attach status tag to broken entities
context.apply_tag_to_entity(
    urn="urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)",
    tag_name="DATA_QUALITY_ALERT"
)

# 2. Append documentation note to alert data teams
context.update_ownership_or_doc(
    urn="urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)",
    note="🚨 [INCIDENT ALERT] 38% null rate detected on order_amount. Investigation underway."
)
```

In the DataHub UI (`http://localhost:9002`), data teams will see the bright red **DATA_QUALITY_ALERT** tag and incident banner on the dataset page and downstream Tableau dashboards.

---

## 📁 Repository Structure

```
├── agent.py          # Complete executable Python AI Agent script
├── requirements.txt  # Python package dependencies
├── README.md         # Documentation & Hackathon quickstart guide
├── LICENSE           # Apache 2.0 Open Source License
├── server.ts         # Full-stack Express backend serving API & UI
├── src/              # Interactive Web Workbench & Visualizer (React + Tailwind)
├── metadata.json     # AI Studio metadata
└── package.json      # Node.js workspace dependencies & scripts
```

---

## 🏆 Hackathon Details
- **Event:** Build with DataHub: The Agent Hackathon
- **Challenge:** Challenge 1 (Agents That Do Real Work)
- **Frameworks Used:** DataHub Context (`datahub-agent-context`, `acryl-datahub`), LangChain Google GenAI (`langchain-google-genai`), Google Gemini 2.5 / 3.6 Flash.
- **License:** [Apache 2.0](./LICENSE)

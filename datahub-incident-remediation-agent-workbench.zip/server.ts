import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initial DataHub Mock Catalog State
let datahubCatalog: Record<string, any> = {
  "urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)": {
    urn: "urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)",
    name: "raw_postgres_orders",
    platform: "postgres",
    type: "DATASET",
    owner: "data-ingestion-team@company.com",
    tags: ["RAW_INGESTION"],
    schema: [
      { fieldPath: "order_id", type: "STRING", nullable: false },
      { fieldPath: "customer_id", type: "STRING", nullable: false },
      { fieldPath: "order_amount", type: "NUMBER", nullable: true, anomaly: "38% null rate spike starting 08:00 AM UTC" },
      { fieldPath: "created_at", type: "TIMESTAMP", nullable: false }
    ],
    upstream: [],
    downstream: ["urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)"],
    description: "Raw postgres ecommerce orders table ingested hourly via Airbyte."
  },
  "urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)": {
    urn: "urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)",
    name: "dbt_transformation_hourly",
    platform: "dbt",
    type: "DATA_JOB",
    owner: "data-engineering@company.com",
    tags: ["DBT_JOB"],
    upstream: ["urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)"],
    downstream: ["urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)"],
    description: "Hourly dbt model running SQL transformations for order aggregation."
  },
  "urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)": {
    urn: "urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)",
    name: "fact_daily_orders",
    platform: "snowflake",
    type: "DATASET",
    owner: "analytics-engineering@company.com",
    tags: ["CORE_ANALYTICS"],
    schema: [
      { fieldPath: "order_id", type: "STRING", nullable: false },
      { fieldPath: "daily_amount_usd", type: "NUMBER", nullable: true, anomaly: "Freshness test failure & invalid null calculations" },
      { fieldPath: "order_date", type: "DATE", nullable: false }
    ],
    upstream: ["urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)"],
    downstream: [
      "urn:li:dataset:(urn:li:dataPlatform:snowflake,fct_customer_revenue,PROD)",
      "urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)"
    ],
    description: "Fact table containing daily aggregated order metrics in Snowflake."
  },
  "urn:li:dataset:(urn:li:dataPlatform:snowflake,fct_customer_revenue,PROD)": {
    urn: "urn:li:dataset:(urn:li:dataPlatform:snowflake,fct_customer_revenue,PROD)",
    name: "fct_customer_revenue",
    platform: "snowflake",
    type: "DATASET",
    owner: "finance-analytics@company.com",
    tags: ["FINANCE"],
    upstream: ["urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)"],
    downstream: ["urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)"],
    description: "Downstream revenue tracking dataset for finance reporting."
  },
  "urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)": {
    urn: "urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)",
    name: "bi_executive_dashboard",
    platform: "tableau",
    type: "DASHBOARD",
    owner: "c-suite-execs@company.com",
    tags: ["EXECUTIVE_KPI"],
    upstream: [
      "urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)",
      "urn:li:dataset:(urn:li:dataPlatform:snowflake,fct_customer_revenue,PROD)"
    ],
    downstream: [],
    description: "C-suite Tableau executive dashboard displaying daily revenue and volume KPIs."
  }
};

const initialCatalogBackup = JSON.parse(JSON.stringify(datahubCatalog));

// API ROUTE 1: Get Project File Contents
app.get("/api/files/:filename", (req, res) => {
  const allowedFiles = ["agent.py", "requirements.txt", "README.md", "LICENSE"];
  const filename = req.params.filename;

  if (!allowedFiles.includes(filename)) {
    return res.status(403).json({ error: "Access denied" });
  }

  try {
    const filePath = path.join(process.cwd(), filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "File not found" });
    }
    const content = fs.readFileSync(filePath, "utf-8");
    res.json({ filename, content });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// API ROUTE 2: Get Catalog Entities
app.get("/api/datahub/catalog", (req, res) => {
  res.json({ catalog: datahubCatalog });
});

// API ROUTE 3: Mutate Entity Tags
app.post("/api/datahub/mutate-tag", (req, res) => {
  const { urn, tag, action } = req.body;
  if (!urn || !tag) {
    return res.status(400).json({ error: "URN and tag are required" });
  }

  const entity = datahubCatalog[urn];
  if (!entity) {
    return res.status(404).json({ error: "Entity not found in catalog" });
  }

  if (action === "remove") {
    entity.tags = entity.tags.filter((t: string) => t !== tag);
  } else {
    if (!entity.tags.includes(tag)) {
      entity.tags.push(tag);
    }
  }

  res.json({ success: true, entity });
});

// API ROUTE 4: Reset Catalog State
app.post("/api/datahub/reset", (req, res) => {
  datahubCatalog = JSON.parse(JSON.stringify(initialCatalogBackup));
  res.json({ success: true, catalog: datahubCatalog });
});

// API ROUTE 5: Agent Remediation Execution
app.post("/api/agent/remediate", async (req, res) => {
  const { taskPrompt, targetDataset } = req.body;
  const promptText = taskPrompt || "Investigate null value spike in fact_daily_orders and notify downstreams";

  const targetUrn = targetDataset || "urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)";
  const targetObj = datahubCatalog[targetUrn] || datahubCatalog["urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)"];

  const rootCauseUrn = "urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)";
  const rootCauseObj = datahubCatalog[rootCauseUrn];

  // Perform Writebacks in Catalog
  if (rootCauseObj && !rootCauseObj.tags.includes("DATA_QUALITY_ALERT")) {
    rootCauseObj.tags.push("DATA_QUALITY_ALERT");
    rootCauseObj.description += " 🚨 [DATA_QUALITY_ALERT] 38% null rate anomaly detected on order_amount.";
  }
  if (targetObj && !targetObj.tags.includes("DATA_QUALITY_ALERT")) {
    targetObj.tags.push("DATA_QUALITY_ALERT");
  }

  const dashUrn = "urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)";
  if (datahubCatalog[dashUrn] && !datahubCatalog[dashUrn].tags.includes("DATA_QUALITY_ALERT")) {
    datahubCatalog[dashUrn].tags.push("DATA_QUALITY_ALERT");
  }

  // Construct Execution Log Steps
  const steps = [
    {
      id: 1,
      title: "1. Search DataHub Catalog Metadata",
      status: "completed",
      details: `Queried DataHub GMS GraphQL search endpoint for term 'orders'. Found matching entity '${targetObj.name}' (${targetUrn}).`
    },
    {
      id: 2,
      title: "2. Inspect Schema & Data Profiling",
      status: "completed",
      details: `Retrieved schema fields for '${targetObj.name}'. Detected field 'daily_amount_usd' experiencing freshness failure and downstream null propagation.`
    },
    {
      id: 3,
      title: "3. Trace Upstream Lineage (Root Cause Analysis)",
      status: "completed",
      details: `Traversed upstream lineage: '${targetObj.name}' ← 'dbt_transformation_hourly' ← 'raw_postgres_orders'. Identified root cause in 'raw_postgres_orders.order_amount' (38% null spike).`
    },
    {
      id: 4,
      title: "4. Trace Downstream Lineage (Impact Analysis)",
      status: "completed",
      details: `Traversed downstream lineage: '${targetObj.name}' → 'fct_customer_revenue' → 'bi_executive_dashboard' (Tableau). Blast radius includes C-suite executive dashboard.`
    },
    {
      id: 5,
      title: "5. Writeback Mutations to DataHub",
      status: "completed",
      details: `Issued GraphQL mutations with include_mutations=True: Attached tag 'DATA_QUALITY_ALERT' to raw_postgres_orders, fact_daily_orders, and bi_executive_dashboard. Appended warning documentation note.`
    }
  ];

  // Try calling Gemini for dynamic summary generation
  let reportMarkdown = "";
  const apiKey = process.env.GEMINI_API_KEY;

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });

      const geminiPrompt = `
      You are the DataHub Incident Remediation Agent. Generate a concise, professional DataOps incident remediation report in clean Markdown format based on this incident:

      User Incident Task: ${promptText}
      Target Dataset: ${targetObj.name}
      Root Cause Entity: raw_postgres_orders (PostgreSQL upstream table)
      Root Cause Anomaly: 38% null rate spike on column 'order_amount' starting at 08:00 AM UTC due to missing NOT NULL constraint.
      Failing Job: dbt_transformation_hourly
      Downstream Impacted Assets:
      - fct_customer_revenue (Snowflake Dataset)
      - bi_executive_dashboard (Tableau C-Suite KPI Dashboard)
      
      Actions Executed in DataHub:
      - Applied tag 'DATA_QUALITY_ALERT' to root cause dataset 'raw_postgres_orders'
      - Applied tag 'DATA_QUALITY_ALERT' to dataset 'fact_daily_orders'
      - Applied tag 'DATA_QUALITY_ALERT' to Tableau dashboard 'bi_executive_dashboard'
      - Updated documentation warning note in DataHub entity profile.

      Provide a 4-part report:
      1. Executive Anomaly Summary
      2. Upstream Root Cause & Lineage Trace
      3. Downstream Blast Radius
      4. DataHub Mutation Writebacks & Action Items for Engineers
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: geminiPrompt
      });

      reportMarkdown = response.text || "";
    } catch (err: any) {
      console.warn("Gemini API call failed, using default markdown report fallback:", err.message);
    }
  }

  if (!reportMarkdown) {
    reportMarkdown = `# 🚨 DataHub Incident Remediation Report

**Incident Task:** ${promptText}  
**Timestamp:** ${new Date().toISOString()}  
**Agent Status:** ✅ REMEDIATION COMPLETED & DATAHUB MUTATED

---

## 1. Executive Anomaly Summary
An automated data quality investigation was executed for dataset \`${targetObj.name}\`. The **DataHub Incident Remediation Agent** successfully performed metadata search, schema inspection, multi-hop lineage traversal, root cause discovery, and tag writeback mutations in DataHub.

---

## 2. Root Cause Analysis
- **Root Cause Entity:** \`raw_postgres_orders\` (\`urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)\`)
- **Anomaly Identified:** Null value spike (38% null rate on \`order_amount\` column).
- **Failure Cause:** Upstream PostgreSQL database migration omitted the \`NOT NULL\` schema constraint on newly ingested guest checkout transactions.

---

## 3. Downstream Blast Radius & Business Impact
Lineage tracing across dbt and Snowflake revealed propagation to:
- ⚙️ **Data Job:** \`dbt_transformation_hourly\`
- 📊 **Dataset:** \`fct_customer_revenue\`
- 📈 **Tableau Dashboard:** \`bi_executive_dashboard\` (C-suite Executive KPIs)

---

## 4. DataHub Writeback Mutations Executed
The agent issued live GraphQL mutations (\`include_mutations=True\`):
- 🏷️ **Added Tag \`DATA_QUALITY_ALERT\`** to \`raw_postgres_orders\`
- 🏷️ **Added Tag \`DATA_QUALITY_ALERT\`** to \`${targetObj.name}\`
- 🏷️ **Added Tag \`DATA_QUALITY_ALERT\`** to \`bi_executive_dashboard\`
- 📝 **Updated Entity Documentation** with warning banner for data consumers.

---

## 5. Engineering Action Items
1. Apply \`NOT NULL\` constraint on PostgreSQL \`raw_postgres_orders.order_amount\`.
2. Re-trigger dbt job \`dbt_transformation_hourly\` after data fix.
3. Clear \`DATA_QUALITY_ALERT\` tags in DataHub once data test assertions pass.
`;
  }

  res.json({
    success: true,
    taskPrompt,
    targetUrn,
    steps,
    catalog: datahubCatalog,
    reportMarkdown,
    writebacks: [
      { urn: rootCauseUrn, name: "raw_postgres_orders", tag: "DATA_QUALITY_ALERT" },
      { urn: targetUrn, name: targetObj.name, tag: "DATA_QUALITY_ALERT" },
      { urn: dashUrn, name: "bi_executive_dashboard", tag: "DATA_QUALITY_ALERT" }
    ]
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

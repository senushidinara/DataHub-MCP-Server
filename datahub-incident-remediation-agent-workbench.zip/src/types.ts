export interface SchemaField {
  fieldPath: string;
  type: string;
  nullable: boolean;
  anomaly?: string;
}

export interface CatalogEntity {
  urn: string;
  name: string;
  platform: string;
  type: 'DATASET' | 'DATA_JOB' | 'DASHBOARD';
  owner: string;
  tags: string[];
  schema?: SchemaField[];
  upstream: string[];
  downstream: string[];
  description: string;
}

export interface AgentStep {
  id: number;
  title: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  details: string;
}

export interface WritebackAction {
  urn: string;
  name: string;
  tag: string;
}

export interface RemediationResult {
  success: boolean;
  taskPrompt: string;
  targetUrn: string;
  steps: AgentStep[];
  catalog: Record<string, CatalogEntity>;
  reportMarkdown: string;
  writebacks: WritebackAction[];
}

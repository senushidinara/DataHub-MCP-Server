import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AgentStudio } from './components/AgentStudio';
import { CatalogInspector } from './components/CatalogInspector';
import { CodeViewer } from './components/CodeViewer';
import { QuickstartGuide } from './components/QuickstartGuide';
import { CatalogEntity, RemediationResult } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'studio' | 'catalog' | 'code' | 'guide'>('studio');
  const [catalog, setCatalog] = useState<Record<string, CatalogEntity>>({});
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [latestResult, setLatestResult] = useState<RemediationResult | null>(null);

  // Fetch Catalog State
  const fetchCatalog = async () => {
    try {
      const res = await fetch('/api/datahub/catalog');
      const data = await res.json();
      if (data.catalog) {
        setCatalog(data.catalog);
      }
    } catch (err) {
      console.error('Failed to fetch catalog:', err);
    }
  };

  useEffect(() => {
    fetchCatalog();
  }, []);

  // Run Agent Remediation
  const handleRunRemediation = async (taskPrompt: string): Promise<RemediationResult | null> => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/agent/remediate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskPrompt }),
      });
      const data: RemediationResult = await res.json();
      if (data.success) {
        setLatestResult(data);
        if (data.catalog) {
          setCatalog(data.catalog);
        }
        return data;
      }
      return null;
    } catch (err) {
      console.error('Agent remediation error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Mutate Entity Tag in Catalog
  const handleMutateTag = async (urn: string, tag: string, action: 'add' | 'remove') => {
    try {
      const res = await fetch('/api/datahub/mutate-tag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ urn, tag, action }),
      });
      const data = await res.json();
      if (data.success) {
        fetchCatalog();
      }
    } catch (err) {
      console.error('Failed to mutate tag:', err);
    }
  };

  // Reset Catalog State
  const handleResetCatalog = async () => {
    try {
      const res = await fetch('/api/datahub/reset', { method: 'POST' });
      const data = await res.json();
      if (data.success && data.catalog) {
        setCatalog(data.catalog);
        setLatestResult(null);
      }
    } catch (err) {
      console.error('Failed to reset catalog:', err);
    }
  };

  // Check if any entity has active DATA_QUALITY_ALERT tag
  const hasActiveIncidents = (Object.values(catalog) as CatalogEntity[]).some((e) =>
    e.tags?.includes('DATA_QUALITY_ALERT')
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasActiveIncidents={hasActiveIncidents}
      />

      <main className="flex-1 pb-12">
        {activeTab === 'studio' && (
          <AgentStudio
            catalog={catalog}
            onRunRemediation={handleRunRemediation}
            onResetCatalog={handleResetCatalog}
            isLoading={isLoading}
            latestResult={latestResult}
          />
        )}

        {activeTab === 'catalog' && (
          <CatalogInspector
            catalog={catalog}
            onMutateTag={handleMutateTag}
            onResetCatalog={handleResetCatalog}
          />
        )}

        {activeTab === 'code' && <CodeViewer />}

        {activeTab === 'guide' && <QuickstartGuide />}
      </main>

      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p>Build with DataHub: The Agent Hackathon • Challenge 1: Agents That Do Real Work</p>
        <p className="mt-1 text-slate-600">Powered by Google Gemini & DataHub Agent Context SDK</p>
      </footer>
    </div>
  );
}

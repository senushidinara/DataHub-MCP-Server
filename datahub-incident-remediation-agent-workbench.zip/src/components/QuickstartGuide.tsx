import React from 'react';
import { BookOpen, Terminal, CheckCircle2, ShieldAlert, Cpu, Sparkles, Server } from 'lucide-react';

export const QuickstartGuide: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <span>Hackathon Judge Quickstart & Verification Guide</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Detailed guide for testing the DataHub Incident Remediation Agent both in simulation mode and with a live local DataHub Docker instance.
        </p>
      </div>

      {/* Grid Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Step 1: Environment Setup */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
            <span className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-xs border border-indigo-500/40">1</span>
            <span>Installation & Environment Setup</span>
          </div>
          <p className="text-xs text-slate-300">
            Install dependencies listed in <code className="text-indigo-300 bg-slate-950 px-1 py-0.5 rounded font-mono">requirements.txt</code>:
          </p>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-200">
            python3 -m venv venv<br />
            source venv/bin/activate<br />
            pip install -r requirements.txt
          </div>
          <p className="text-[11px] text-slate-400">
            Set your Gemini API key in <code className="text-slate-300 font-mono">.env</code>:
            <code className="block bg-slate-950 p-2 rounded border border-slate-800 mt-1 text-slate-300">GOOGLE_API_KEY="your-gemini-key"</code>
          </p>
        </div>

        {/* Step 2: Instant Simulation Mode */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
            <span className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-xs border border-indigo-500/40">2</span>
            <span>Option A: Instant Simulation Mode (No Docker Needed)</span>
          </div>
          <p className="text-xs text-slate-300">
            Run the Python agent directly in dry-run mode to verify Gemini reasoning, lineage traversal, and tag mutation logic instantly:
          </p>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-200">
            python agent.py --simulate --task "Investigate null spike in fact_daily_orders"
          </div>
          <p className="text-[11px] text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Output generates <code className="text-slate-300 font-mono">incident_report_&lt;timestamp&gt;.md</code>
          </p>
        </div>

        {/* Step 3: Live DataHub Connection */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
            <span className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-xs border border-indigo-500/40">3</span>
            <span>Option B: Live DataHub Docker Quickstart</span>
          </div>
          <p className="text-xs text-slate-300">
            To connect to a live DataHub instance running on localhost:8080:
          </p>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-slate-200">
            pip install acryl-datahub<br />
            datahub docker quickstart<br /><br />
            python agent.py --datahub-url "http://localhost:8080"
          </div>
        </div>

        {/* Step 4: Verification in DataHub UI */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
            <span className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-xs border border-indigo-500/40">4</span>
            <span>Verifying DataHub Mutation Writebacks</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            When the agent runs with <code className="text-amber-300 bg-amber-950/60 px-1 rounded font-mono">include_mutations=True</code>, it issues GraphQL mutations to DataHub GMS.
          </p>
          <div className="p-3 bg-amber-950/20 border border-amber-500/30 rounded-lg text-xs space-y-1.5 text-slate-300">
            <div className="font-bold text-amber-400 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5" /> What to inspect in DataHub UI (http://localhost:9002):
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li>Dataset <code className="text-amber-300 font-mono">raw_postgres_orders</code> has <code className="text-amber-300 font-mono">DATA_QUALITY_ALERT</code> tag attached.</li>
              <li>Downstream Tableau Dashboard <code className="text-amber-300 font-mono">bi_executive_dashboard</code> displays warning tag.</li>
              <li>Documentation section includes the agent's incident warning banner.</li>
            </ul>
          </div>
        </div>

      </div>

    </div>
  );
};

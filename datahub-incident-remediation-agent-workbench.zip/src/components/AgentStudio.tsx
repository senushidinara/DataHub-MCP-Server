import React, { useState } from 'react';
import { Bot, Play, RefreshCw, ArrowRight, ShieldAlert, CheckCircle2, FileText, Tag, Database, Layers, Sparkles, Copy, Download, Check } from 'lucide-react';
import { CatalogEntity, RemediationResult, AgentStep } from '../types';

interface AgentStudioProps {
  catalog: Record<string, CatalogEntity>;
  onRunRemediation: (taskPrompt: string) => Promise<RemediationResult | null>;
  onResetCatalog: () => void;
  isLoading: boolean;
  latestResult: RemediationResult | null;
}

export const AgentStudio: React.FC<AgentStudioProps> = ({
  catalog,
  onRunRemediation,
  onResetCatalog,
  isLoading,
  latestResult,
}) => {
  const [taskPrompt, setTaskPrompt] = useState(
    'Investigate null value spike in fact_daily_orders.amount and notify downstreams'
  );
  const [copiedReport, setCopiedReport] = useState(false);

  const presetTasks = [
    {
      title: 'Null Spike Anomaly',
      prompt: 'Investigate null value spike in fact_daily_orders.amount and notify downstreams',
      dataset: 'fact_daily_orders',
    },
    {
      title: 'PostgreSQL Schema Drift',
      prompt: 'Trace upstream schema drift in raw_postgres_orders and tag failing dbt models',
      dataset: 'raw_postgres_orders',
    },
    {
      title: 'Executive Dashboard Alert',
      prompt: 'Audit freshness delay in bi_executive_dashboard and apply DATA_QUALITY_ALERT',
      dataset: 'bi_executive_dashboard',
    },
  ];

  const handleCopyReport = () => {
    if (latestResult?.reportMarkdown) {
      navigator.clipboard.writeText(latestResult.reportMarkdown);
      setCopiedReport(true);
      setTimeout(() => setCopiedReport(false), 2000);
    }
  };

  const handleDownloadReport = () => {
    if (latestResult?.reportMarkdown) {
      const blob = new Blob([latestResult.reportMarkdown], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `datahub_incident_report_${Date.now()}.md`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  // Lineage node definitions for visualization
  const lineageNodes = [
    {
      urn: 'urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)',
      name: 'raw_postgres_orders',
      type: 'PostgreSQL',
      badge: 'Upstream Source',
      hasTag: catalog['urn:li:dataset:(urn:li:dataPlatform:postgres,raw_postgres_orders,PROD)']?.tags?.includes('DATA_QUALITY_ALERT'),
      isRootCause: true,
    },
    {
      urn: 'urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)',
      name: 'dbt_transformation_hourly',
      type: 'dbt Job',
      badge: 'ETL Pipeline',
      hasTag: catalog['urn:li:dataJob:(urn:li:dataFlow:dbt,dbt_transformation_hourly,PROD)']?.tags?.includes('DATA_QUALITY_ALERT'),
      isRootCause: false,
    },
    {
      urn: 'urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)',
      name: 'fact_daily_orders',
      type: 'Snowflake',
      badge: 'Target Dataset',
      hasTag: catalog['urn:li:dataset:(urn:li:dataPlatform:snowflake,fact_daily_orders,PROD)']?.tags?.includes('DATA_QUALITY_ALERT'),
      isRootCause: false,
    },
    {
      urn: 'urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)',
      name: 'bi_executive_dashboard',
      type: 'Tableau',
      badge: 'Downstream KPI',
      hasTag: catalog['urn:li:dashboard:(urn:li:dataPlatform:tableau,bi_executive_dashboard,PROD)']?.tags?.includes('DATA_QUALITY_ALERT'),
      isRootCause: false,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-12">
          <Bot className="w-96 h-96 text-indigo-400" />
        </div>
        
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-2">
            <Sparkles className="w-4 h-4" />
            <span>DataOps AI Agent Powered by Gemini 3.6 & DataHub Context</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Autonomous Incident Remediation & Lineage Mutation
          </h1>
          <p className="mt-2 text-slate-300 text-sm sm:text-base leading-relaxed">
            The agent queries DataHub's context platform to inspect dataset schemas, trace upstream root causes across dbt & PostgreSQL, compute downstream blast radius, and execute <strong className="text-amber-400">writeback mutations</strong> (applying <code className="text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/30">DATA_QUALITY_ALERT</code> status tags).
          </p>
        </div>
      </div>

      {/* Control Launcher & Incident Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <Bot className="w-4 h-4 text-indigo-400" />
            <span>Agent Incident Remediation Prompt</span>
          </label>
          <button
            onClick={onResetCatalog}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 transition-colors px-2.5 py-1 bg-slate-800 rounded-md border border-slate-700"
          >
            <RefreshCw className="w-3 h-3" /> Reset DataHub Catalog
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={taskPrompt}
            onChange={(e) => setTaskPrompt(e.target.value)}
            placeholder="Describe the data incident..."
            className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={() => onRunRemediation(taskPrompt)}
            disabled={isLoading || !taskPrompt.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold px-6 py-3 rounded-lg flex items-center justify-center gap-2 transition-all shadow-md shadow-indigo-600/20 whitespace-nowrap"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Agent Remediating...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Run Agent Remediation</span>
              </>
            )}
          </button>
        </div>

        {/* Preset Task Cards */}
        <div className="pt-2">
          <span className="text-xs font-medium text-slate-400 block mb-2">Preset Incident Scenarios:</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {presetTasks.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setTaskPrompt(preset.prompt);
                  onRunRemediation(preset.prompt);
                }}
                className="text-left p-2.5 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 rounded-lg text-xs transition-all group"
              >
                <div className="font-semibold text-slate-200 group-hover:text-indigo-400 flex items-center justify-between">
                  <span>{preset.title}</span>
                  <ArrowRight className="w-3 h-3 text-slate-600 group-hover:text-indigo-400" />
                </div>
                <div className="text-slate-400 mt-1 truncate">{preset.prompt}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive Lineage Visualizer & Tag Writeback Highlights */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <span>DataHub Lineage & Writeback Visualizer</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Live graph state showing upstream root causes, ETL jobs, and downstream impacted Tableau dashboards.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700"></span> Clean
            </span>
            <span className="flex items-center gap-1 text-amber-400 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span> DATA_QUALITY_ALERT
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 relative py-4">
          {lineageNodes.map((node, index) => (
            <div
              key={index}
              className={`p-4 rounded-xl border transition-all relative ${
                node.hasTag
                  ? 'bg-amber-950/20 border-amber-500/60 shadow-lg shadow-amber-500/10'
                  : 'bg-slate-950 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-0.5 bg-slate-800 rounded-md">
                  {node.badge}
                </span>
                <span className="text-xs font-mono text-slate-500">{node.type}</span>
              </div>

              <div className="font-bold text-sm text-slate-100 truncate">{node.name}</div>

              {/* Tag Status */}
              <div className="mt-3 flex items-center gap-1.5">
                {node.hasTag ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40">
                    <ShieldAlert className="w-3 h-3" /> DATA_QUALITY_ALERT
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-slate-800 text-slate-400">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Healthy
                  </span>
                )}
              </div>

              {node.isRootCause && node.hasTag && (
                <div className="mt-2 text-[11px] text-amber-300/80 bg-amber-900/30 p-1.5 rounded border border-amber-500/20">
                  ⚠️ Root Cause Anomaly Detected
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Execution Results Section */}
      {latestResult && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Agent Execution Steps Log */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Bot className="w-5 h-5 text-indigo-400" />
              <span>Agent Execution Log</span>
            </h3>

            <div className="space-y-3">
              {latestResult.steps.map((step) => (
                <div
                  key={step.id}
                  className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1.5 text-xs"
                >
                  <div className="flex items-center justify-between font-semibold text-slate-200">
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>{step.title}</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                      COMPLETED
                    </span>
                  </div>
                  <p className="text-slate-400 leading-relaxed font-mono">{step.details}</p>
                </div>
              ))}
            </div>

            {/* Mutations Executed */}
            <div className="pt-2 border-t border-slate-800">
              <div className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-amber-400" />
                <span>DataHub Mutations Executed ({latestResult.writebacks.length})</span>
              </div>
              <div className="space-y-1.5">
                {latestResult.writebacks.map((wb, idx) => (
                  <div key={idx} className="p-2 bg-amber-950/20 border border-amber-500/30 rounded text-xs flex items-center justify-between">
                    <span className="font-mono text-slate-300 text-[11px] truncate">{wb.name}</span>
                    <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-400 font-bold rounded text-[10px]">
                      +{wb.tag}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Markdown Report Card */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <span>Incident Remediation Report</span>
              </h3>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyReport}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-md flex items-center gap-1 transition-colors"
                >
                  {copiedReport ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedReport ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={handleDownloadReport}
                  className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-md flex items-center gap-1 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .md</span>
                </button>
              </div>
            </div>

            {/* Markdown Body Display */}
            <div className="bg-slate-950 p-5 rounded-lg border border-slate-800 font-sans text-xs sm:text-sm text-slate-300 leading-relaxed overflow-y-auto max-h-[500px] whitespace-pre-wrap font-mono">
              {latestResult.reportMarkdown}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};

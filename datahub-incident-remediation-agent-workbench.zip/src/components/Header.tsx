import React from 'react';
import { Bot, ShieldAlert, Database, Code, BookOpen, Sparkles, CheckCircle2 } from 'lucide-react';

interface HeaderProps {
  activeTab: 'studio' | 'catalog' | 'code' | 'guide';
  setActiveTab: (tab: 'studio' | 'catalog' | 'code' | 'guide') => void;
  hasActiveIncidents: boolean;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, hasActiveIncidents }) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Hackathon Badge */}
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg text-white shadow-lg shadow-indigo-500/20">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-100 text-lg tracking-tight">DataHub Incident Agent</span>
                <span className="px-2 py-0.5 text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Gemini 3.6
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-1.5">
                <span>Build with DataHub: The Agent Hackathon</span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-400 font-medium">Challenge 1</span>
              </p>
            </div>
          </div>

          {/* Incident Status Indicator */}
          <div className="hidden md:flex items-center px-3 py-1.5 bg-slate-800/80 border border-slate-700/60 rounded-full text-xs">
            {hasActiveIncidents ? (
              <span className="flex items-center text-amber-400 font-medium gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                </span>
                Active Incident Tagged in DataHub
              </span>
            ) : (
              <span className="flex items-center text-emerald-400 font-medium gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> DataHub Catalog Healthy
              </span>
            )}
          </div>

          {/* Navigation Tabs */}
          <nav className="flex space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('studio')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'studio'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span className="hidden sm:inline">Agent Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('catalog')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all relative ${
                activeTab === 'catalog'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Database className="w-4 h-4" />
              <span className="hidden sm:inline">DataHub Catalog</span>
              {hasActiveIncidents && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full border-2 border-slate-900 animate-pulse"></span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Code className="w-4 h-4" />
              <span className="hidden sm:inline">Submission Code</span>
            </button>

            <button
              onClick={() => setActiveTab('guide')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'guide'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Judge Guide</span>
            </button>
          </nav>

        </div>
      </div>
    </header>
  );
};

import React, { useState, useEffect } from 'react';
import { Code, Copy, Check, Download, FileText, Terminal, RefreshCw } from 'lucide-react';

export const CodeViewer: React.FC = () => {
  const [activeFile, setActiveFile] = useState<string>('agent.py');
  const [fileContent, setFileContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  const files = [
    { name: 'agent.py', label: 'File B: agent.py', icon: Terminal, lang: 'python' },
    { name: 'requirements.txt', label: 'File A: requirements.txt', icon: FileText, lang: 'text' },
    { name: 'README.md', label: 'File C: README.md', icon: FileText, lang: 'markdown' },
    { name: 'LICENSE', label: 'File D: LICENSE', icon: FileText, lang: 'text' },
  ];

  const fetchFile = async (filename: string) => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/files/${filename}`);
      const data = await res.json();
      if (data.content) {
        setFileContent(data.content);
      } else {
        setFileContent('# Error loading file');
      }
    } catch (err) {
      setFileContent('# Failed to load file from disk');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFile(activeFile);
  }, [activeFile]);

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([fileContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-xl">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Code className="w-5 h-5 text-indigo-400" />
            <span>Hackathon Submission Files Inspector</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Read-only live view of exact Python project files created on disk for submission.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy File'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download {activeFile}</span>
          </button>
        </div>
      </div>

      {/* Code Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        
        {/* File Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950 overflow-x-auto">
          {files.map((f) => {
            const Icon = f.icon;
            const isActive = f.name === activeFile;

            return (
              <button
                key={f.name}
                onClick={() => setActiveFile(f.name)}
                className={`flex items-center space-x-2 px-5 py-3 text-xs font-semibold transition-all border-r border-slate-800/80 whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 text-indigo-400 border-b-2 border-b-indigo-500'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{f.label}</span>
              </button>
            );
          })}
        </div>

        {/* Code Content */}
        <div className="p-6 bg-slate-950 relative overflow-x-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-20 text-slate-400 text-xs gap-2 font-mono">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Loading file content from server...</span>
            </div>
          ) : (
            <pre className="font-mono text-xs text-slate-200 leading-relaxed overflow-x-auto">
              <code>{fileContent}</code>
            </pre>
          )}
        </div>

      </div>

    </div>
  );
};

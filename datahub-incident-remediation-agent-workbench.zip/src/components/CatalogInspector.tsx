import React, { useState } from 'react';
import { Database, Tag, ShieldAlert, CheckCircle2, User, Layers, FileText, Plus, Trash2, RefreshCw } from 'lucide-react';
import { CatalogEntity } from '../types';

interface CatalogInspectorProps {
  catalog: Record<string, CatalogEntity>;
  onMutateTag: (urn: string, tag: string, action: 'add' | 'remove') => void;
  onResetCatalog: () => void;
}

export const CatalogInspector: React.FC<CatalogInspectorProps> = ({
  catalog,
  onMutateTag,
  onResetCatalog,
}) => {
  const [selectedUrn, setSelectedUrn] = useState<string>(
    Object.keys(catalog)[0] || ''
  );
  const [newCustomTag, setNewCustomTag] = useState('');

  const selectedEntity = catalog[selectedUrn] || (Object.values(catalog)[0] as CatalogEntity);

  const handleAddTag = () => {
    if (newCustomTag.trim() && selectedUrn) {
      onMutateTag(selectedUrn, newCustomTag.trim().toUpperCase(), 'add');
      setNewCustomTag('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-xl">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-indigo-400" />
            <span>DataHub Catalog Metadata Inspector</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Live metadata view reflecting DataHub entities, column schemas, tags, and documentation updated by agent mutation writebacks.
          </p>
        </div>

        <button
          onClick={onResetCatalog}
          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 self-start sm:self-auto transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Catalog State</span>
        </button>
      </div>

      {/* Main Grid: Catalog List & Entity Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Entity List Selector */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 block mb-2">
            Catalog Entities ({Object.keys(catalog).length})
          </span>

          <div className="space-y-1.5">
            {(Object.values(catalog) as CatalogEntity[]).map((entity) => {
              const isSelected = entity.urn === selectedUrn;
              const hasAlertTag = entity.tags.includes('DATA_QUALITY_ALERT');

              return (
                <button
                  key={entity.urn}
                  onClick={() => setSelectedUrn(entity.urn)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    isSelected
                      ? 'bg-indigo-950/60 border-indigo-500/80 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-200 truncate">{entity.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-800 rounded text-slate-400">
                      {entity.platform}
                    </span>
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">{entity.type}</span>
                    {hasAlertTag ? (
                      <span className="px-1.5 py-0.5 rounded font-bold text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                        <ShieldAlert className="w-2.5 h-2.5" /> DATA_QUALITY_ALERT
                      </span>
                    ) : (
                      <span className="text-emerald-500 flex items-center gap-1 font-medium text-[10px]">
                        <CheckCircle2 className="w-2.5 h-2.5" /> Healthy
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Entity Details Pane */}
        {selectedEntity && (
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
            
            {/* Header / Basic Info */}
            <div className="border-b border-slate-800 pb-4 space-y-2">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <span>{selectedEntity.name}</span>
                  <span className="text-xs font-mono px-2 py-0.5 bg-slate-800 text-indigo-400 rounded-md border border-slate-700">
                    {selectedEntity.platform}
                  </span>
                </h2>
                <span className="text-xs font-mono text-slate-500">{selectedEntity.type}</span>
              </div>
              <p className="text-xs font-mono text-slate-400 break-all">{selectedEntity.urn}</p>
              <p className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-lg border border-slate-800 mt-2">
                {selectedEntity.description}
              </p>
            </div>

            {/* Tags & Mutation Tools */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Tag className="w-4 h-4 text-amber-400" />
                  <span>DataHub Status Tags & Writebacks</span>
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                {selectedEntity.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 border ${
                      tag === 'DATA_QUALITY_ALERT'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    <span>{tag}</span>
                    <button
                      onClick={() => onMutateTag(selectedEntity.urn, tag, 'remove')}
                      className="hover:text-red-400 transition-colors"
                      title="Remove tag"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>

              {/* Manual Tag Addition Test Box */}
              <div className="flex gap-2 pt-2">
                <input
                  type="text"
                  value={newCustomTag}
                  onChange={(e) => setNewCustomTag(e.target.value)}
                  placeholder="e.g. INCIDENT_IN_PROGRESS"
                  className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 flex-1"
                />
                <button
                  onClick={handleAddTag}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Apply Tag Mutation
                </button>
              </div>
            </div>

            {/* Schema Table (if dataset) */}
            {selectedEntity.schema && (
              <div className="space-y-3 pt-2">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-400" />
                  <span>Schema Columns & Anomaly Detection</span>
                </span>

                <div className="overflow-x-auto border border-slate-800 rounded-lg">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                      <tr>
                        <th className="px-4 py-2.5 font-bold">Field Path</th>
                        <th className="px-4 py-2.5 font-bold">Type</th>
                        <th className="px-4 py-2.5 font-bold">Nullable</th>
                        <th className="px-4 py-2.5 font-bold">Status / Anomaly</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 bg-slate-900">
                      {selectedEntity.schema.map((col, idx) => (
                        <tr key={idx} className={col.anomaly ? 'bg-amber-950/20' : ''}>
                          <td className="px-4 py-2.5 font-mono text-slate-200 font-medium">{col.fieldPath}</td>
                          <td className="px-4 py-2.5 font-mono text-slate-400">{col.type}</td>
                          <td className="px-4 py-2.5 font-mono text-slate-400">{col.nullable ? 'Yes' : 'No'}</td>
                          <td className="px-4 py-2.5">
                            {col.anomaly ? (
                              <span className="text-amber-400 font-semibold flex items-center gap-1">
                                <ShieldAlert className="w-3 h-3" /> {col.anomaly}
                              </span>
                            ) : (
                              <span className="text-emerald-400">Normal</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Ownership */}
            <div className="pt-2 border-t border-slate-800 flex items-center gap-2 text-xs text-slate-400">
              <User className="w-4 h-4 text-slate-500" />
              <span>Assigned Owner:</span>
              <span className="font-mono text-slate-200">{selectedEntity.owner}</span>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
